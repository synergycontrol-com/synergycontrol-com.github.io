access.exe + parse.dll

This file was designed for Win32 Console mode to parse 
Synergy script and logic files from the command line.  
It will display syntax errors if there are any.

If distributing this executable, be sure to include the following files:
    access.exe - created here
    parse.dll - created here
    cw3230.dll - from borland bin directory
