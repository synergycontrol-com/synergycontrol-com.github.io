Copy synergy.exe to the "C:\Program Files\Synergy Configuration" directory

Copy the rest of the files to the "C:\Program Files\Synergy Configuration\BIN" directory

Run the upgrade.bat file

end